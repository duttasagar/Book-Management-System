
# from pymongo.mongo_client import MongoClient
# from pymongo.server_api import ServerApi

# uri = "mongodb+srv://duttasagar39:<db_password>@bookstore.u3opj.mongodb.net/?retryWrites=true&w=majority&appName=BookStore"

# client = MongoClient(uri, server_api=ServerApi('1'))

# db =client.todo_db
# collection = db['book_store']