from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorClient
import motor.motor_asyncio

# MongoDB Client setup
client = AsyncIOMotorClient("mongodb://localhost:27017")  # Change connection string as needed
db = client.BookStore  # Replace 'bookstore' with your database name
collection = db.books  # Collection where books are stored

# Book Model for MongoDB Schema
class Book(BaseModel):
    title: str
    author: str
    isbn: str
    price: float
    quantity: int
    published_date: datetime
    genre: str
    description: Optional[str] = None
    last_updated: datetime = Field(default_factory=datetime.today())
    created_at: datetime = Field(default_factory=datetime.today())

# Pydantic Model for Data Validation
class BookIn(BaseModel):
    title: str
    author: str
    isbn: str
    price: float
    quantity: int
    published_date: datetime
    genre: str
    description: Optional[str] = None

# Endpoint Response Model
class BookOut(BookIn):
    id: str


















































# from pydantic import BaseModel,Field
# from datetime import datetime
# from typing import Optional

# class BookModel(BaseModel):
#     title: str = Field(...)
#     author : str = Field(...)
#     isbn  : str = Field(...)
#     price: float = Field(...)
#     quantity: int = Field(...)
#     published_date :Optional[datetime] = Field(default_factory=datetime.now)
#     genre : Optional[str] = Field(...)
#     description: Optional[str] = Field(...)
#     last_updated_timestamp : Optional[datetime] = Field(default_factory=datetime.now)
#     created_timestamp : Optional[datetime] = Field(default_factory=datetime.now)